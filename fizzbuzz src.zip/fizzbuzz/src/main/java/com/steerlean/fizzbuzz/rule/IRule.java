package com.steerlean.fizzbuzz.rule;

public interface IRule {

	String parse(Integer number);

}
